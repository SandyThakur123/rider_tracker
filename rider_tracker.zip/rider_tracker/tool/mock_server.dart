// In-memory backend for local testing. See README for the debug endpoints.
//   dart run tool/mock_server.dart [--port 8080]

import 'dart:async';
import 'dart:convert';
import 'dart:io';

final trips = <String, Map<String, dynamic>>{};
final locations = <String, List<Map<String, dynamic>>>{};
final seenIdempotencyKeys = <String>{};
int failNext = 0;
int delayMs = 0;

Future<void> main(List<String> args) async {
  var port = 8080;
  final i = args.indexOf('--port');
  if (i != -1 && i + 1 < args.length) port = int.parse(args[i + 1]);

  final server = await HttpServer.bind(InternetAddress.anyIPv4, port);
  stdout.writeln('mock rider backend listening on http://0.0.0.0:$port');
  await for (final req in server) {
    unawaited(_handle(req));
  }
}

Future<void> _handle(HttpRequest req) async {
  final path = req.uri.path;
  final method = req.method;
  final segs = req.uri.pathSegments;
  Map<String, dynamic> body = const {};
  if (method == 'POST' || method == 'PUT') {
    final raw = await utf8.decoder.bind(req).join();
    if (raw.isNotEmpty) {
      try {
        body = jsonDecode(raw) as Map<String, dynamic>;
      } catch (_) {
        return _send(req, 400, {'error': 'bad json'});
      }
    }
  }
  stdout.writeln('$method $path ${body.isEmpty ? '' : jsonEncode(body)}');

  if (delayMs > 0) await Future<void>.delayed(Duration(milliseconds: delayMs));

  if (segs.isNotEmpty && segs.first == 'debug') {
    if (segs.length == 3 && segs[1] == 'fail') {
      failNext = int.parse(segs[2]);
      return _send(req, 200, {'failNext': failNext});
    }
    if (segs.length == 3 && segs[1] == 'delay') {
      delayMs = int.parse(segs[2]);
      return _send(req, 200, {'delayMs': delayMs});
    }
    if (segs.length == 3 && segs[1] == 'end') {
      final t = trips[segs[2]];
      if (t == null) return _send(req, 404, {'error': 'unknown trip'});
      t['status'] = 'ended';
      t['endedAt'] = DateTime.now().toUtc().toIso8601String();
      t['endedBy'] = 'server';
      return _send(req, 200, t);
    }
    if (segs.length == 2 && segs[1] == 'dump') {
      return _send(req, 200, {'trips': trips, 'locations': locations});
    }
    return _send(req, 404, {'error': 'unknown debug op'});
  }

  if (failNext > 0) {
    failNext--;
    stdout.writeln('   -> simulated 503 ($failNext more to go)');
    return _send(req, 503, {'error': 'simulated outage'});
  }

  // retried request whose first attempt went through
  final idem = req.headers.value('Idempotency-Key');
  if (idem != null && seenIdempotencyKeys.contains(idem)) {
    stdout.writeln('   -> replay of $idem, ok');
    return _send(req, 200, {'replayed': true});
  }

  if (method == 'POST' && path == '/trip/start') {
    final id = body['tripId'] as String?;
    if (id == null) return _send(req, 400, {'error': 'tripId required'});
    if (trips.containsKey(id)) {
      return _send(req, 409, {'error': 'trip already exists'});
    }
    trips[id] = {
      'tripId': id,
      'status': 'active',
      'startedAt':
          body['startedAt'] ?? DateTime.now().toUtc().toIso8601String(),
    };
    locations[id] = [];
    _remember(idem);
    return _send(req, 201, trips[id]!);
  }

  if (method == 'POST' && path == '/trip/location') {
    final id = body['tripId'] as String?;
    final t = id == null ? null : trips[id];
    if (t == null) return _send(req, 404, {'error': 'unknown trip'});
    if (t['status'] != 'active') {
      return _send(req, 409, {'error': 'trip is not active'});
    }
    locations[id]!.add(body);
    _remember(idem);
    return _send(req, 200, {'count': locations[id]!.length});
  }

  if (method == 'POST' && path == '/trip/end') {
    final id = body['tripId'] as String?;
    final t = id == null ? null : trips[id];
    if (t == null) return _send(req, 404, {'error': 'unknown trip'});
    if (t['status'] != 'active') {
      return _send(req, 409, {'error': 'trip already ended'});
    }
    t['status'] = 'ended';
    t['endedAt'] = body['endedAt'];
    t['distanceMeters'] = body['distanceMeters'];
    t['maxSpeed'] = body['maxSpeed'];
    _remember(idem);
    return _send(req, 200, t);
  }

  if (method == 'GET' && segs.length == 2 && segs.first == 'trip') {
    final t = trips[segs[1]];
    if (t == null) return _send(req, 404, {'error': 'unknown trip'});
    return _send(req, 200, {
      ...t,
      'locationCount': locations[segs[1]]?.length ?? 0,
      'locations': locations[segs[1]],
    });
  }

  return _send(req, 404, {'error': 'no such route'});
}

void _remember(String? key) {
  if (key != null) seenIdempotencyKeys.add(key);
}

Future<void> _send(HttpRequest req, int status, Object body) async {
  req.response
    ..statusCode = status
    ..headers.contentType = ContentType.json
    ..write(jsonEncode(body));
  await req.response.close();
}
