package com.subtlelabs.rider_tracker

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
