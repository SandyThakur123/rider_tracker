import 'package:flutter_test/flutter_test.dart';
import 'package:rider_tracker/config.dart';
import 'package:rider_tracker/models/fix.dart';
import 'package:rider_tracker/tracking/trip_tracker.dart';

// Connaught Place, Delhi. Roughly 1 degree of lat = 111 km, so 0.0001 = ~11m.
const _lat0 = 28.6139;
const _lng0 = 77.2090;

final _t0 = DateTime.utc(2026, 9, 8, 10, 0, 0);

Fix fix({
  double dLat = 0,
  double dLng = 0,
  int sec = 0,
  double accuracy = 8,
  double? speed,
  double? speedAcc,
}) {
  return Fix(
    lat: _lat0 + dLat,
    lng: _lng0 + dLng,
    accuracy: accuracy,
    timestamp: _t0.add(Duration(seconds: sec)),
    speedMps: speed,
    speedAccuracy: speedAcc,
  );
}

// "now" for the stale check - just a bit after the last fix in each test
DateTime nowAt(int sec) => _t0.add(Duration(seconds: sec + 1));

void main() {
  group('haversine', () {
    test('~11m per 0.0001 deg of latitude', () {
      final d = haversineMeters(_lat0, _lng0, _lat0 + 0.0001, _lng0);
      expect(d, closeTo(11.1, 0.2));
    });
  });

  group('TripTracker', () {
    test('first fix is accepted with zero distance', () {
      final t = TripTracker();
      final r = t.feed(fix(speed: 3), now: nowAt(0));
      expect(r.accepted, isTrue);
      expect(r.distanceDelta, 0);
      expect(t.distanceMeters, 0);
      expect(t.currentSpeedMps, 3);
    });

    test('accumulates distance along a normal ride', () {
      final t = TripTracker();
      // ~11m every 2s = 5.5 m/s, a relaxed bicycle pace
      for (var i = 0; i < 10; i++) {
        final r = t.feed(
          fix(dLat: 0.0001 * i, sec: i * 2, speed: 5.5),
          now: nowAt(i * 2),
        );
        expect(r.accepted, isTrue, reason: 'fix $i');
      }
      expect(t.distanceMeters, closeTo(100, 2));
      expect(t.maxSpeedMps, closeTo(5.5, 0.01));
      expect(t.acceptedCount, 10);
      expect(t.rejectedCount, 0);
    });

    test('rejects a fix with poor accuracy', () {
      final t = TripTracker();
      t.feed(fix(), now: nowAt(0));
      final r = t.feed(fix(dLat: 0.0001, sec: 2, accuracy: 120), now: nowAt(2));
      expect(r.accepted, isFalse);
      expect(r.reason, RejectReason.poorAccuracy);
      expect(t.distanceMeters, 0);
    });

    test('rejects a stale (cached) fix', () {
      final t = TripTracker();
      // fix is from 5 min ago relative to "now"
      final r = t.feed(fix(), now: _t0.add(const Duration(minutes: 5)));
      expect(r.accepted, isFalse);
      expect(r.reason, RejectReason.stale);
    });

    test('rejects out of order timestamps', () {
      final t = TripTracker();
      t.feed(fix(sec: 10), now: nowAt(10));
      final r = t.feed(fix(dLat: 0.0001, sec: 5), now: nowAt(10));
      expect(r.accepted, isFalse);
      expect(r.reason, RejectReason.outOfOrder);
    });

    test('single GPS jump does not add distance or speed', () {
      final t = TripTracker();
      t.feed(fix(speed: 5), now: nowAt(0));
      t.feed(fix(dLat: 0.0001, sec: 2, speed: 5), now: nowAt(2));

      // suddenly 1km away, 2 seconds later (500 m/s)
      final jump = t.feed(
        fix(dLat: 0.0001, dLng: 0.01, sec: 4, speed: 5),
        now: nowAt(4),
      );
      expect(jump.accepted, isFalse);
      expect(jump.reason, RejectReason.jump);

      // back on the route
      final back = t.feed(fix(dLat: 0.0002, sec: 6, speed: 5), now: nowAt(6));
      expect(back.accepted, isTrue);

      expect(t.distanceMeters, closeTo(22, 1));
      expect(t.maxSpeedMps, closeTo(5, 0.01));
      expect(t.rejectedCount, 1);
    });

    test('re-anchors after several consistent far-away fixes', () {
      final t = TripTracker(
        config: const TrackingConfig(suspectsToReanchor: 3),
      );
      t.feed(fix(speed: 5), now: nowAt(0));
      t.feed(fix(dLat: 0.0001, sec: 2, speed: 5), now: nowAt(2));

      // receiver comes back ~1km away and keeps reporting from there,
      // moving normally. Happens after a tunnel or after the app was dead
      // for a while with no timestamp gap to explain it.
      final r1 = t.feed(fix(dLng: 0.01, sec: 4, speed: 5), now: nowAt(4));
      final r2 = t.feed(
        fix(dLng: 0.01, dLat: 0.0001, sec: 6, speed: 5),
        now: nowAt(6),
      );
      final r3 = t.feed(
        fix(dLng: 0.01, dLat: 0.0002, sec: 8, speed: 5),
        now: nowAt(8),
      );
      expect(r1.accepted, isFalse);
      expect(r2.accepted, isFalse);
      expect(r3.accepted, isTrue);
      expect(r3.reanchored, isTrue);
      expect(r3.distanceDelta, 0);

      // and from here on we count normally
      final r4 = t.feed(
        fix(dLng: 0.01, dLat: 0.0003, sec: 10, speed: 5),
        now: nowAt(10),
      );
      expect(r4.accepted, isTrue);
      expect(r4.distanceDelta, closeTo(11.1, 0.5));
      expect(t.distanceMeters, closeTo(22.2, 1));
    });

    test('does not re-anchor when the far fixes disagree with each other', () {
      final t = TripTracker(
        config: const TrackingConfig(suspectsToReanchor: 3),
      );
      t.feed(fix(), now: nowAt(0));
      t.feed(fix(dLat: 0.0001, sec: 2), now: nowAt(2));
      // three garbage fixes in three different places
      expect(t.feed(fix(dLng: 0.01, sec: 4), now: nowAt(4)).accepted, isFalse);
      expect(t.feed(fix(dLng: -0.01, sec: 6), now: nowAt(6)).accepted, isFalse);
      expect(t.feed(fix(dLat: 0.02, sec: 8), now: nowAt(8)).accepted, isFalse);
      expect(t.distanceMeters, closeTo(11.1, 0.5));
    });

    test('one bad fix before a real relocation does not block re-anchor', () {
      final t = TripTracker(
        config: const TrackingConfig(suspectsToReanchor: 3),
      );
      t.feed(fix(), now: nowAt(0));
      t.feed(fix(dLat: 0.0001, sec: 2), now: nowAt(2));
      // garbage, then three consistent fixes from the new place
      t.feed(fix(dLat: 0.05, sec: 4), now: nowAt(4));
      t.feed(fix(dLng: 0.01, sec: 6), now: nowAt(6));
      t.feed(fix(dLng: 0.01, dLat: 0.0001, sec: 8), now: nowAt(8));
      final r = t.feed(fix(dLng: 0.01, dLat: 0.0002, sec: 10), now: nowAt(10));
      expect(r.accepted, isTrue);
      expect(r.reanchored, isTrue);
    });

    test('ignores drift while stationary', () {
      final t = TripTracker();
      t.feed(fix(speed: 0), now: nowAt(0));
      // wobbling around by 4-8m with speed 0 and accuracy 10m
      t.feed(fix(dLat: 0.00005, sec: 2, speed: 0, accuracy: 10), now: nowAt(2));
      t.feed(fix(dLng: 0.00007, sec: 4, speed: 0, accuracy: 10), now: nowAt(4));
      t.feed(
        fix(dLat: -0.00004, sec: 6, speed: 0, accuracy: 10),
        now: nowAt(6),
      );
      expect(t.distanceMeters, 0);
      expect(t.acceptedCount, 4);
    });

    test('platform speed spike is replaced by derived speed', () {
      final t = TripTracker();
      t.feed(fix(speed: 5), now: nowAt(0));
      // moved 11m in 2s (5.5 m/s) but chipset claims 30 m/s
      final r = t.feed(fix(dLat: 0.0001, sec: 2, speed: 30), now: nowAt(2));
      expect(r.accepted, isTrue);
      expect(r.speedMps, closeTo(5.5, 0.1));
      expect(t.maxSpeedMps, closeTo(5.5, 0.1));
    });

    test('platform speed above the ceiling is not used for max', () {
      final t = TripTracker();
      t.feed(fix(speed: 5), now: nowAt(0));
      final r = t.feed(fix(dLat: 0.0001, sec: 2, speed: 80), now: nowAt(2));
      expect(r.accepted, isTrue);
      expect(t.maxSpeedMps, lessThan(10));
    });

    test('falls back to derived speed when platform gives none', () {
      final t = TripTracker();
      t.feed(fix(), now: nowAt(0));
      final r = t.feed(fix(dLat: 0.0002, sec: 2), now: nowAt(2));
      expect(r.speedMps, closeTo(11.1, 0.2));
    });

    test('restores from a previous snapshot', () {
      final t = TripTracker(
        distanceMeters: 5000,
        maxSpeedMps: 9,
        acceptedCount: 100,
        rejectedCount: 3,
        lastAccepted: fix(sec: 0),
      );
      // process was dead for a minute, rider moved 300m in that time
      final r = t.feed(fix(dLat: 0.0027, sec: 60, speed: 5), now: nowAt(60));
      expect(r.accepted, isTrue);
      expect(t.distanceMeters, closeTo(5300, 5));
      expect(t.maxSpeedMps, 9);
      expect(t.acceptedCount, 101);
    });
  });
}
