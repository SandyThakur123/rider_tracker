import 'package:flutter_test/flutter_test.dart';
import 'package:rider_tracker/data/app_database.dart';
import 'package:rider_tracker/data/trip_repository.dart';
import 'package:rider_tracker/models/fix.dart';
import 'package:rider_tracker/models/track_point.dart';
import 'package:rider_tracker/models/trip.dart';
import 'package:rider_tracker/sync/api_client.dart';
import 'package:rider_tracker/sync/sync_worker.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

class FakeApi implements TripApi {
  final calls = <String>[];
  final started = <String>{};
  final ended = <String>{};
  final locations = <String, int>{};

  int failNext = 0;

  // 0-based call number that should throw
  int? failAtCall;
  Exception failWith = TransientApiError('offline');

  final serverEnded = <String>{};

  int _callNo = 0;

  void _maybeFail(String call) {
    calls.add(call);
    final no = _callNo++;
    if (failNext > 0) {
      failNext--;
      throw failWith;
    }
    if (failAtCall == no) throw failWith;
  }

  @override
  Future<void> startTrip(Trip trip) async {
    _maybeFail('start:${trip.id}');
    if (started.contains(trip.id)) {
      throw TripStateConflict(409, 'already exists');
    }
    started.add(trip.id);
  }

  @override
  Future<void> uploadLocation(TrackPoint p) async {
    _maybeFail('loc:${p.id}');
    if (serverEnded.contains(p.tripId)) {
      throw TripStateConflict(409, 'trip not active');
    }
    locations[p.tripId] = (locations[p.tripId] ?? 0) + 1;
  }

  @override
  Future<void> endTrip(Trip trip) async {
    _maybeFail('end:${trip.id}');
    if (ended.contains(trip.id) || serverEnded.contains(trip.id)) {
      throw TripStateConflict(409, 'already ended');
    }
    ended.add(trip.id);
  }

  @override
  Future<Map<String, dynamic>?> getTrip(String id) async {
    _maybeFail('get:$id');
    if (!started.contains(id)) return null;
    return {
      'tripId': id,
      'status': serverEnded.contains(id) ? 'ended' : 'active',
    };
  }
}

final _t0 = DateTime.utc(2026, 9, 8, 10, 0, 0);

Fix _fix(int i) => Fix(
  lat: 28.6139 + i * 0.0001,
  lng: 77.2090,
  accuracy: 8,
  timestamp: _t0.add(Duration(seconds: i * 2)),
  speedMps: 5,
);

void main() {
  sqfliteFfiInit();

  late AppDatabase db;
  late TripRepository repo;
  late FakeApi api;

  setUp(() async {
    db = await AppDatabase.openAt(
      inMemoryDatabasePath,
      factory: databaseFactoryFfi,
    );
    repo = TripRepository(db);
    api = FakeApi();
  });

  tearDown(() => db.close());

  Future<Trip> activeTripWithPoints(String id, int n) async {
    final t = Trip(id: id, status: TripStatus.active, startedAt: _t0);
    await repo.insertTrip(t);
    for (var i = 0; i < n; i++) {
      await repo.insertPoint(id, _fix(i), accepted: true);
    }
    await repo.insertPoint(id, _fix(n), accepted: false, rejectReason: 'jump');
    return t;
  }

  group('SyncWorker', () {
    test('uploads start, accepted points, then end - in order', () async {
      await activeTripWithPoints('T1', 3);
      await repo.endTrip('T1');

      final w = SyncWorker(repo, api);
      await w.kick();

      expect(api.calls.first, 'start:T1');
      expect(api.calls.last, 'end:T1');
      expect(api.locations['T1'], 3);
      expect(await repo.pendingUploadCount(), 0);
      final t = (await repo.getTrip('T1'))!;
      expect(t.startSynced, isTrue);
      expect(t.endSynced, isTrue);
    });

    test(
      'offline: nothing is lost, everything goes through on reconnect',
      () async {
        await activeTripWithPoints('T1', 5);

        api.failNext = 100;
        final w = SyncWorker(repo, api);
        await w.kick();
        expect(await repo.pendingUploadCount(), 5);
        expect((await repo.getTrip('T1'))!.startSynced, isFalse);

        // still inside the backoff window
        api.calls.clear();
        await w.kick();
        expect(api.calls, isEmpty);

        // fresh worker = what the connectivity callback does (resets backoff)
        api.failNext = 0;
        await SyncWorker(repo, api).kick();
        expect(await repo.pendingUploadCount(), 0);
        expect(api.locations['T1'], 5);
      },
    );

    test(
      'partial batch failure keeps what got through, resumes from there',
      () async {
        await activeTripWithPoints('T1', 4);

        // 0 = start, 1-2 = points, 3 = third point fails
        api.failAtCall = 3;
        await SyncWorker(repo, api).kick();
        expect(api.locations['T1'], 2);
        expect(await repo.pendingUploadCount(), 2);

        api.calls.clear();
        await SyncWorker(repo, api).kick();
        expect(api.calls, ['loc:3', 'loc:4']);
        expect(api.locations['T1'], 4);
        expect(await repo.pendingUploadCount(), 0);

        api.calls.clear();
        await SyncWorker(repo, api).kick();
        expect(api.calls, isEmpty);
      },
    );

    test(
      'same action submitted twice: 409 on start is treated as success',
      () async {
        await activeTripWithPoints('T1', 1);
        // response to our first start call got lost
        api.started.add('T1');

        await SyncWorker(repo, api).kick();
        expect((await repo.getTrip('T1'))!.startSynced, isTrue);
        expect(api.locations['T1'], 1);
      },
    );

    test(
      'same action submitted twice: 409 on end is treated as success',
      () async {
        await activeTripWithPoints('T1', 1);
        await repo.endTrip('T1');
        api.started.add('T1');
        api.ended.add('T1');

        await SyncWorker(repo, api).kick();
        expect((await repo.getTrip('T1'))!.endSynced, isTrue);
      },
    );

    test(
      'server ended the trip: local trip is closed and points discarded',
      () async {
        await activeTripWithPoints('T1', 3);
        await SyncWorker(repo, api).kick();

        api.serverEnded.add('T1');
        await repo.insertPoint('T1', _fix(10), accepted: true);

        String? endedLocally;
        final w = SyncWorker(
          repo,
          api,
          onTripEndedByServer: (id) async {
            endedLocally = id;
            await repo.endTrip(id);
          },
        );
        await w.kick();

        expect(endedLocally, 'T1');
        final t = (await repo.getTrip('T1'))!;
        expect(t.status, TripStatus.ended);
        expect(t.endSynced, isTrue);
        expect(await repo.pendingUploadCount(), 0);
        expect(api.locations['T1'], 3);
      },
    );

    test('reconcileActiveTrip closes a trip the server says is over', () async {
      final t = await activeTripWithPoints('T1', 1);
      await SyncWorker(repo, api).kick();
      api.serverEnded.add('T1');

      var closed = false;
      final w = SyncWorker(
        repo,
        api,
        onTripEndedByServer: (id) async {
          closed = true;
          await repo.endTrip(id);
        },
      );
      await w.reconcileActiveTrip((await repo.getTrip(t.id))!);
      expect(closed, isTrue);
      expect(await repo.activeTrip(), isNull);
    });

    test('reconcileActiveTrip is a no-op while offline', () async {
      final t = await activeTripWithPoints('T1', 1);
      await SyncWorker(repo, api).kick();
      api.failNext = 1;
      await SyncWorker(
        repo,
        api,
      ).reconcileActiveTrip((await repo.getTrip(t.id))!);
      expect(await repo.activeTrip(), isNotNull);
    });
  });

  group('TripRepository', () {
    test('only one active trip; second End is a no-op', () async {
      await activeTripWithPoints('T1', 0);
      expect(await repo.endTrip('T1'), isTrue);
      expect(await repo.endTrip('T1'), isFalse);
      expect(await repo.activeTrip(), isNull);
    });

    test('duplicate insert of the same trip id is ignored', () async {
      final t = Trip(id: 'T1', status: TripStatus.active, startedAt: _t0);
      await repo.insertTrip(t);
      await repo.insertTrip(t.copyWith(distanceMeters: 999));
      expect((await repo.getTrip('T1'))!.distanceMeters, 0);
    });

    test('lastAcceptedFix skips rejected points', () async {
      await activeTripWithPoints('T1', 2);
      final f = await repo.lastAcceptedFix('T1');
      expect(f!.timestamp, _fix(1).timestamp);
    });
  });
}
