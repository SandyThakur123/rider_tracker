import 'package:sqflite/sqflite.dart';

import '../models/fix.dart';
import '../models/track_point.dart';
import '../models/trip.dart';
import 'app_database.dart';

class TripRepository {
  TripRepository(this._db);

  final AppDatabase _db;
  Database get _sql => _db.db;

  Future<Trip?> activeTrip() async {
    final rows = await _sql.query(
      'trips',
      where: 'status = ?',
      whereArgs: ['active'],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return Trip.fromMap(rows.first);
  }

  Future<Trip?> getTrip(String id) async {
    final rows = await _sql.query(
      'trips',
      where: 'id = ?',
      whereArgs: [id],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return Trip.fromMap(rows.first);
  }

  Future<List<Trip>> allTrips() async {
    final rows = await _sql.query('trips', orderBy: 'started_at DESC');
    return rows.map(Trip.fromMap).toList();
  }

  Future<void> insertTrip(Trip trip) => _sql.insert(
    'trips',
    trip.toMap(),
    conflictAlgorithm: ConflictAlgorithm.ignore,
  );

  Future<void> updateStats(
    String tripId, {
    required double distanceMeters,
    required double maxSpeedMps,
    required int acceptedCount,
    required int rejectedCount,
  }) {
    return _sql.update(
      'trips',
      {
        'distance_m': distanceMeters,
        'max_speed_mps': maxSpeedMps,
        'accepted_count': acceptedCount,
        'rejected_count': rejectedCount,
      },
      where: 'id = ?',
      whereArgs: [tripId],
    );
  }

  Future<bool> endTrip(String tripId, {DateTime? at}) async {
    final n = await _sql.update(
      'trips',
      {
        'status': TripStatus.ended.name,
        'ended_at': (at ?? DateTime.now().toUtc()).millisecondsSinceEpoch,
      },
      where: 'id = ? AND status = ?',
      whereArgs: [tripId, TripStatus.active.name],
    );
    return n > 0;
  }

  Future<void> markStartSynced(String tripId) => _sql.update(
    'trips',
    {'start_synced': 1},
    where: 'id = ?',
    whereArgs: [tripId],
  );

  Future<void> markEndSynced(String tripId) => _sql.update(
    'trips',
    {'end_synced': 1},
    where: 'id = ?',
    whereArgs: [tripId],
  );

  /// Trips that still have something to upload.
  Future<List<Trip>> tripsNeedingSync() async {
    final rows = await _sql.rawQuery('''
      SELECT t.* FROM trips t
      WHERE t.start_synced = 0
         OR (t.status = 'ended' AND t.end_synced = 0)
         OR EXISTS (SELECT 1 FROM points p
                    WHERE p.trip_id = t.id AND p.accepted = 1 AND p.synced = 0)
      ORDER BY t.started_at ASC
    ''');
    return rows.map(Trip.fromMap).toList();
  }

  Future<int> pendingUploadCount() async {
    final r = await _sql.rawQuery(
      'SELECT COUNT(*) AS c FROM points WHERE accepted = 1 AND synced = 0',
    );
    return Sqflite.firstIntValue(r) ?? 0;
  }

  Future<int> insertPoint(
    String tripId,
    Fix fix, {
    required bool accepted,
    String? rejectReason,
  }) {
    return _sql.insert('points', {
      'trip_id': tripId,
      'lat': fix.lat,
      'lng': fix.lng,
      'accuracy_m': fix.accuracy,
      'speed_mps': fix.speedMps,
      'ts': fix.timestamp.millisecondsSinceEpoch,
      'accepted': accepted ? 1 : 0,
      'reject_reason': rejectReason,
    });
  }

  /// Last accepted fix of a trip. Used to rebuild the tracker after the
  /// process was killed mid-trip.
  Future<Fix?> lastAcceptedFix(String tripId) async {
    final rows = await _sql.query(
      'points',
      where: 'trip_id = ? AND accepted = 1',
      whereArgs: [tripId],
      orderBy: 'id DESC',
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return TrackPoint.fromRow(rows.first).fix;
  }

  Future<List<TrackPoint>> unsyncedPoints(
    String tripId, {
    int limit = 50,
  }) async {
    final rows = await _sql.query(
      'points',
      where: 'trip_id = ? AND accepted = 1 AND synced = 0',
      whereArgs: [tripId],
      orderBy: 'id ASC',
      limit: limit,
    );
    return rows.map(TrackPoint.fromRow).toList();
  }

  Future<void> markPointsSynced(List<int> ids) async {
    if (ids.isEmpty) return;
    final q = List.filled(ids.length, '?').join(',');
    await _sql.rawUpdate('UPDATE points SET synced = 1 WHERE id IN ($q)', ids);
  }

  /// Used when the server tells us the trip is gone / already closed -
  /// nothing more we can do with those points.
  Future<void> discardUnsynced(String tripId) => _sql.update(
    'points',
    {'synced': 2},
    where: 'trip_id = ? AND synced = 0',
    whereArgs: [tripId],
  );

  Future<List<TrackPoint>> pointsForTrip(String tripId) async {
    final rows = await _sql.query(
      'points',
      where: 'trip_id = ?',
      whereArgs: [tripId],
      orderBy: 'id ASC',
    );
    return rows.map(TrackPoint.fromRow).toList();
  }
}
