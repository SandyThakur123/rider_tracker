enum TripStatus { active, ended }

class Trip {
  const Trip({
    required this.id,
    required this.status,
    required this.startedAt,
    this.endedAt,
    this.distanceMeters = 0,
    this.maxSpeedMps = 0,
    this.acceptedCount = 0,
    this.rejectedCount = 0,
    this.startSynced = false,
    this.endSynced = false,
  });

  final String id;
  final TripStatus status;
  final DateTime startedAt;
  final DateTime? endedAt;
  final double distanceMeters;
  final double maxSpeedMps;
  final int acceptedCount;
  final int rejectedCount;
  final bool startSynced;
  final bool endSynced;

  bool get isActive => status == TripStatus.active;

  Duration get duration =>
      (endedAt ?? DateTime.now().toUtc()).difference(startedAt);

  Trip copyWith({
    TripStatus? status,
    DateTime? endedAt,
    double? distanceMeters,
    double? maxSpeedMps,
    int? acceptedCount,
    int? rejectedCount,
    bool? startSynced,
    bool? endSynced,
  }) {
    return Trip(
      id: id,
      status: status ?? this.status,
      startedAt: startedAt,
      endedAt: endedAt ?? this.endedAt,
      distanceMeters: distanceMeters ?? this.distanceMeters,
      maxSpeedMps: maxSpeedMps ?? this.maxSpeedMps,
      acceptedCount: acceptedCount ?? this.acceptedCount,
      rejectedCount: rejectedCount ?? this.rejectedCount,
      startSynced: startSynced ?? this.startSynced,
      endSynced: endSynced ?? this.endSynced,
    );
  }

  Map<String, dynamic> toMap() => {
    'id': id,
    'status': status.name,
    'started_at': startedAt.millisecondsSinceEpoch,
    'ended_at': endedAt?.millisecondsSinceEpoch,
    'distance_m': distanceMeters,
    'max_speed_mps': maxSpeedMps,
    'accepted_count': acceptedCount,
    'rejected_count': rejectedCount,
    'start_synced': startSynced ? 1 : 0,
    'end_synced': endSynced ? 1 : 0,
  };

  factory Trip.fromMap(Map<String, dynamic> m) {
    return Trip(
      id: m['id'] as String,
      status: TripStatus.values.byName(m['status'] as String),
      startedAt: DateTime.fromMillisecondsSinceEpoch(
        m['started_at'] as int,
        isUtc: true,
      ),
      endedAt: m['ended_at'] == null
          ? null
          : DateTime.fromMillisecondsSinceEpoch(
              m['ended_at'] as int,
              isUtc: true,
            ),
      distanceMeters: (m['distance_m'] as num).toDouble(),
      maxSpeedMps: (m['max_speed_mps'] as num).toDouble(),
      acceptedCount: m['accepted_count'] as int,
      rejectedCount: m['rejected_count'] as int,
      startSynced: m['start_synced'] == 1,
      endSynced: m['end_synced'] == 1,
    );
  }
}
