import 'fix.dart';

class TrackPoint {
  const TrackPoint({
    required this.id,
    required this.tripId,
    required this.fix,
    required this.accepted,
    this.rejectReason,
    this.synced = false,
  });

  final int id;
  final String tripId;
  final Fix fix;
  final bool accepted;
  final String? rejectReason;
  final bool synced;

  factory TrackPoint.fromRow(Map<String, dynamic> r) {
    return TrackPoint(
      id: r['id'] as int,
      tripId: r['trip_id'] as String,
      fix: Fix(
        lat: (r['lat'] as num).toDouble(),
        lng: (r['lng'] as num).toDouble(),
        accuracy: (r['accuracy_m'] as num).toDouble(),
        speedMps: (r['speed_mps'] as num?)?.toDouble(),
        timestamp: DateTime.fromMillisecondsSinceEpoch(
          r['ts'] as int,
          isUtc: true,
        ),
      ),
      accepted: r['accepted'] == 1,
      rejectReason: r['reject_reason'] as String?,
      synced: r['synced'] == 1,
    );
  }
}
