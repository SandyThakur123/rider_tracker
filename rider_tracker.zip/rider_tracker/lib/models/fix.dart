import 'package:geolocator/geolocator.dart';

/// One GPS reading. Independent from geolocator so the tracker can be tested
/// without the plugin.
class Fix {
  const Fix({
    required this.lat,
    required this.lng,
    required this.accuracy,
    required this.timestamp,
    this.speedMps,
    this.speedAccuracy,
    this.isMocked = false,
  });

  final double lat;
  final double lng;

  final double accuracy;
  final DateTime timestamp;

  // null when the platform didn't report one
  final double? speedMps;
  final double? speedAccuracy;
  final bool isMocked;

  factory Fix.fromPosition(Position p) {
    return Fix(
      lat: p.latitude,
      lng: p.longitude,
      accuracy: p.accuracy,
      timestamp: p.timestamp.toUtc(),
      // iOS reports -1 when speed is invalid, android has the hasSpeed flag
      speedMps: (p.hasSpeed && p.speed >= 0) ? p.speed : null,
      speedAccuracy: p.hasSpeedAccuracy ? p.speedAccuracy : null,
      isMocked: p.isMocked,
    );
  }

  Map<String, dynamic> toMap() => {
    'lat': lat,
    'lng': lng,
    'accuracy': accuracy,
    'ts': timestamp.millisecondsSinceEpoch,
    'speed': speedMps,
    'speedAccuracy': speedAccuracy,
    'mocked': isMocked,
  };

  static Fix? fromMap(Map<String, dynamic>? m) {
    if (m == null) return null;
    return Fix(
      lat: (m['lat'] as num).toDouble(),
      lng: (m['lng'] as num).toDouble(),
      accuracy: (m['accuracy'] as num).toDouble(),
      timestamp: DateTime.fromMillisecondsSinceEpoch(
        m['ts'] as int,
        isUtc: true,
      ),
      speedMps: (m['speed'] as num?)?.toDouble(),
      speedAccuracy: (m['speedAccuracy'] as num?)?.toDouble(),
      isMocked: m['mocked'] == true,
    );
  }

  @override
  String toString() =>
      'Fix($lat, $lng ±${accuracy.toStringAsFixed(0)}m, ${speedMps?.toStringAsFixed(1)} m/s, $timestamp)';
}
