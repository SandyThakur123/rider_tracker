class TrackingConfig {
  const TrackingConfig({
    this.maxAccuracyMeters = 50,
    this.maxSpeedMps = 45,
    this.maxFixAge = const Duration(seconds: 30),
    this.minDistanceMeters = 2,
    this.stationarySpeedMps = 0.5,
    this.speedDisagreeMps = 8,
    this.suspectsToReanchor = 3,
    this.platformDistanceFilterMeters = 5,
  });

  final double maxAccuracyMeters;

  // ~160 km/h, anything faster between two fixes is a GPS jump
  final double maxSpeedMps;

  // android sometimes replays a cached fix as the first event of a stream
  final Duration maxFixAge;

  final double minDistanceMeters;

  // below this we treat the rider as parked and ignore drift
  final double stationarySpeedMps;

  // platform speed this far above distance/time is a spike
  final double speedDisagreeMps;

  // consecutive consistent "jump" fixes before we re-anchor
  final int suspectsToReanchor;

  final int platformDistanceFilterMeters;
}

const kTracking = TrackingConfig();

// empty = local only
const kApiBaseUrl = String.fromEnvironment('API_BASE_URL');

bool get kSyncEnabled => kApiBaseUrl.isNotEmpty;
