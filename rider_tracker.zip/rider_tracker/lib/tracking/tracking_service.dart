import 'dart:async';
import 'dart:ui';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:geolocator/geolocator.dart';

import '../config.dart';
import '../data/app_database.dart';
import '../data/trip_repository.dart';
import '../models/fix.dart';
import '../models/trip.dart';
import '../sync/api_client.dart';
import '../sync/sync_worker.dart';
import 'trip_tracker.dart';

// UI writes the trip row, then pokes the service with `refresh`. The service
// reads the db and decides whether it should be streaming or not.
class ServiceMessages {
  static const refresh = 'refresh';
  static const stop = 'stop';
  static const update = 'update'; // service -> ui
  static const error = 'error'; // service -> ui
}

class TrackingService {
  final _svc = FlutterBackgroundService();

  static Future<void> configure() async {
    await FlutterBackgroundService().configure(
      androidConfiguration: AndroidConfiguration(
        onStart: onServiceStart,
        autoStart: false,
        // if the phone reboots mid trip we want to pick it back up
        autoStartOnBoot: true,
        isForegroundMode: true,
        initialNotificationTitle: 'Rider Tracker',
        initialNotificationContent: 'Starting…',
        foregroundServiceNotificationId: 4210,
        foregroundServiceTypes: [AndroidForegroundType.location],
      ),
      iosConfiguration: IosConfiguration(
        autoStart: false,
        onForeground: onServiceStart,
        onBackground: onIosBackground,
      ),
    );
  }

  Future<bool> isRunning() => _svc.isRunning();

  Future<void> ensureRunning() async {
    if (!await _svc.isRunning()) {
      await _svc.startService();
    }
    _svc.invoke(ServiceMessages.refresh);
  }

  void refresh() => _svc.invoke(ServiceMessages.refresh);

  Stream<Map<String, dynamic>?> get updates => _svc.on(ServiceMessages.update);
  Stream<Map<String, dynamic>?> get errors => _svc.on(ServiceMessages.error);
}

@pragma('vm:entry-point')
Future<bool> onIosBackground(ServiceInstance service) async {
  // iOS background fetch, ~30s every few hours. Only good for flushing uploads.
  WidgetsFlutterBinding.ensureInitialized();
  DartPluginRegistrant.ensureInitialized();
  if (!kSyncEnabled) return true;
  try {
    final db = await AppDatabase.open();
    final repo = TripRepository(db);
    final worker = SyncWorker(repo, ApiClient(kApiBaseUrl));
    await worker.kick();
    await db.close();
  } catch (e) {
    debugPrint('ios bg fetch: $e');
  }
  return true;
}

@pragma('vm:entry-point')
Future<void> onServiceStart(ServiceInstance service) async {
  DartPluginRegistrant.ensureInitialized();
  final runner = _ServiceRunner(service);
  await runner.run();
}

class _ServiceRunner {
  _ServiceRunner(this.service);

  final ServiceInstance service;

  late final AppDatabase _db;
  late final TripRepository _repo;
  SyncWorker? _sync;
  SyncStatus? _syncStatus;

  StreamSubscription<Position>? _posSub;
  Trip? _trip;
  TripTracker? _tracker;
  Fix? _lastFix;
  TrackerResult? _lastResult;
  Timer? _idleTimer;
  bool _reconciling = false;
  bool _pokedWhileBusy = false;

  Future<void> run() async {
    _db = await AppDatabase.open();
    _repo = TripRepository(_db);

    if (kSyncEnabled) {
      _sync = SyncWorker(
        _repo,
        ApiClient(kApiBaseUrl),
        onStatus: (s) {
          _syncStatus = s;
          _emitUpdate();
        },
        onTripEndedByServer: (id) async {
          await _repo.endTrip(id);
          await _reconcile();
        },
      );
    }

    service.on(ServiceMessages.refresh).listen((_) => _reconcile());
    service.on(ServiceMessages.stop).listen((_) => _shutdown());

    // also what resumes a trip after boot / kill
    await _reconcile();

    if (_trip != null && _sync != null) {
      await _sync!.reconcileActiveTrip(_trip!);
    }
    _sync?.start();
  }

  Future<void> _reconcile() async {
    // a poke that lands mid-reconcile must not get lost, the UI may have
    // just inserted the trip row
    if (_reconciling) {
      _pokedWhileBusy = true;
      return;
    }
    _reconciling = true;
    try {
      do {
        _pokedWhileBusy = false;
        final active = await _repo.activeTrip();
        if (active != null && _trip?.id != active.id) {
          await _startTracking(active);
        } else if (active == null && _trip != null) {
          await _stopTracking();
        } else if (active == null) {
          _scheduleIdleStop();
        }
        _emitUpdate();
      } while (_pokedWhileBusy);
    } finally {
      _reconciling = false;
    }
  }

  Future<void> _startTracking(Trip trip) async {
    await _posSub?.cancel();
    _idleTimer?.cancel();

    _trip = trip;
    _tracker = TripTracker(
      distanceMeters: trip.distanceMeters,
      maxSpeedMps: trip.maxSpeedMps,
      acceptedCount: trip.acceptedCount,
      rejectedCount: trip.rejectedCount,
      lastAccepted: await _repo.lastAcceptedFix(trip.id),
    );
    _lastFix = null;
    _lastResult = null;

    await _setNotification('Trip in progress', 'Waiting for GPS…');

    final settings = _locationSettings();
    _posSub = Geolocator.getPositionStream(locationSettings: settings).listen(
      _onPosition,
      onError: (Object e) {
        service.invoke(ServiceMessages.error, {'message': e.toString()});
      },
    );
  }

  LocationSettings _locationSettings() {
    final distanceFilter = kTracking.platformDistanceFilterMeters;
    if (defaultTargetPlatform == TargetPlatform.android) {
      return AndroidSettings(
        accuracy: LocationAccuracy.best,
        distanceFilter: distanceFilter,
        intervalDuration: const Duration(seconds: 1),
        // no foregroundNotificationConfig here: flutter_background_service
        // already owns the foreground service / notification.
      );
    }
    if (defaultTargetPlatform == TargetPlatform.iOS) {
      return AppleSettings(
        accuracy: LocationAccuracy.bestForNavigation,
        activityType: ActivityType.otherNavigation,
        distanceFilter: distanceFilter,
        pauseLocationUpdatesAutomatically: false,
        allowBackgroundLocationUpdates: true,
        showBackgroundLocationIndicator: true,
      );
    }
    return LocationSettings(
      accuracy: LocationAccuracy.best,
      distanceFilter: distanceFilter,
    );
  }

  Future<void> _onPosition(Position pos) async {
    final trip = _trip;
    final tracker = _tracker;
    if (trip == null || tracker == null) return;

    final fix = Fix.fromPosition(pos);
    final result = tracker.feed(fix);
    _lastFix = fix;
    _lastResult = result;

    await _repo.insertPoint(
      trip.id,
      fix,
      accepted: result.accepted,
      rejectReason: result.reason,
    );
    await _repo.updateStats(
      trip.id,
      distanceMeters: tracker.distanceMeters,
      maxSpeedMps: tracker.maxSpeedMps,
      acceptedCount: tracker.acceptedCount,
      rejectedCount: tracker.rejectedCount,
    );
    _trip = trip.copyWith(
      distanceMeters: tracker.distanceMeters,
      maxSpeedMps: tracker.maxSpeedMps,
      acceptedCount: tracker.acceptedCount,
      rejectedCount: tracker.rejectedCount,
    );

    if (result.accepted) {
      final km = (tracker.distanceMeters / 1000).toStringAsFixed(2);
      final kmh = (tracker.currentSpeedMps * 3.6).toStringAsFixed(0);
      await _setNotification('Trip in progress', '$km km · $kmh km/h');
      _sync?.kick();
    }
    _emitUpdate();
  }

  Future<void> _stopTracking() async {
    await _posSub?.cancel();
    _posSub = null;
    _trip = null;
    _tracker = null;
    await _setNotification('Rider Tracker', 'Trip ended');
    _sync?.kick();
    _scheduleIdleStop();
  }

  // no active trip: wait for uploads to finish, then stop
  void _scheduleIdleStop() {
    _idleTimer?.cancel();
    _idleTimer = Timer.periodic(const Duration(seconds: 5), (t) async {
      if (_trip != null) {
        t.cancel();
        return;
      }
      final pending = await _sync?.hasPending() ?? false;
      // give up waiting after ~2 min, the next app launch will resume the sync
      if (!pending || t.tick >= 24) {
        t.cancel();
        await _shutdown();
      }
    });
  }

  Future<void> _shutdown() async {
    await _posSub?.cancel();
    await _sync?.stop();
    _idleTimer?.cancel();
    await _db.close();
    await service.stopSelf();
  }

  Future<void> _setNotification(String title, String body) async {
    final s = service;
    if (s is AndroidServiceInstance && await s.isForegroundService()) {
      await s.setForegroundNotificationInfo(title: title, content: body);
    }
  }

  void _emitUpdate() {
    service.invoke(ServiceMessages.update, {
      'trip': _trip?.toMap(),
      'fix': _lastFix?.toMap(),
      'currentSpeed': _tracker?.currentSpeedMps ?? 0,
      'accepted': _lastResult?.accepted,
      'reason': _lastResult?.reason,
      'reanchored': _lastResult?.reanchored ?? false,
      'sync': _syncStatus?.toMap(),
    });
  }
}
