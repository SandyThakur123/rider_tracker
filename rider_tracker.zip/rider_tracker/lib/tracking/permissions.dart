import 'dart:io';

import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart' as ph;

enum LocationPermissionState {
  serviceDisabled,
  denied,
  deniedForever,

  whileInUse,
  always,
}

class Permissions {
  // service on -> while in use -> always -> notifications (android 13+).
  // whileInUse is enough to start a trip, the UI just shows a warning.
  static Future<LocationPermissionState> requestForTracking() async {
    if (!await Geolocator.isLocationServiceEnabled()) {
      return LocationPermissionState.serviceDisabled;
    }

    var perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) {
      perm = await Geolocator.requestPermission();
    }
    if (perm == LocationPermission.denied) {
      return LocationPermissionState.denied;
    }
    if (perm == LocationPermission.deniedForever) {
      return LocationPermissionState.deniedForever;
    }

    if (Platform.isAndroid) {
      // Android 13+ needs this for the foreground service notification to
      // actually show. Not fatal if refused.
      await ph.Permission.notification.request();
    }

    if (perm == LocationPermission.always) {
      return LocationPermissionState.always;
    }

    // Android 10+ / iOS: "always" is a separate prompt. On Android 11+ it
    // bounces the user to settings, which is why it's only asked on Start
    // and not, say, every time the home screen opens.
    final always = await ph.Permission.locationAlways.request();
    if (always.isGranted) return LocationPermissionState.always;
    return LocationPermissionState.whileInUse;
  }

  static Future<LocationPermissionState> current() async {
    if (!await Geolocator.isLocationServiceEnabled()) {
      return LocationPermissionState.serviceDisabled;
    }
    switch (await Geolocator.checkPermission()) {
      case LocationPermission.always:
        return LocationPermissionState.always;
      case LocationPermission.whileInUse:
        return LocationPermissionState.whileInUse;
      case LocationPermission.deniedForever:
        return LocationPermissionState.deniedForever;
      case LocationPermission.denied:
      case LocationPermission.unableToDetermine:
        return LocationPermissionState.denied;
    }
  }
}
