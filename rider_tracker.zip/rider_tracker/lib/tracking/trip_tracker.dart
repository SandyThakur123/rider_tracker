import 'dart:math';

import '../config.dart';
import '../models/fix.dart';

class RejectReason {
  static const poorAccuracy = 'poor_accuracy';
  static const stale = 'stale';
  static const outOfOrder = 'out_of_order';
  static const jump = 'jump';
}

class TrackerResult {
  const TrackerResult._({
    required this.accepted,
    this.reason,
    this.speedMps = 0,
    this.distanceDelta = 0,
    this.reanchored = false,
  });

  const TrackerResult.rejected(String reason)
    : this._(accepted: false, reason: reason);

  const TrackerResult.accepted({
    required double speedMps,
    required double distanceDelta,
    bool reanchored = false,
  }) : this._(
         accepted: true,
         speedMps: speedMps,
         distanceDelta: distanceDelta,
         reanchored: reanchored,
       );

  final bool accepted;
  final String? reason;
  final double speedMps;
  final double distanceDelta;

  /// Accepted after a run of "jumps": the receiver settled somewhere far
  /// away and we trust it now, but the gap was not counted.
  final bool reanchored;
}

/// Takes raw fixes, keeps the running distance / max speed for one trip.
/// No platform code in here so it can be unit tested.
class TripTracker {
  /// Pass stored values to pick up where a previous process left off.
  TripTracker({
    this.config = kTracking,
    this.distanceMeters = 0,
    this.maxSpeedMps = 0,
    this.acceptedCount = 0,
    this.rejectedCount = 0,
    Fix? lastAccepted,
  }) : _last = lastAccepted;

  final TrackingConfig config;

  double distanceMeters;
  double maxSpeedMps;
  int acceptedCount;
  int rejectedCount;
  double currentSpeedMps = 0;

  Fix? _last;
  Fix? get lastAccepted => _last;

  // consecutive fixes that failed the jump check
  final List<Fix> _suspects = [];

  TrackerResult feed(Fix fix, {DateTime? now}) {
    final r = _evaluate(fix, now ?? DateTime.now().toUtc());
    if (r.accepted) {
      acceptedCount++;
      distanceMeters += r.distanceDelta;
      currentSpeedMps = r.speedMps;
      if (r.speedMps > maxSpeedMps) maxSpeedMps = r.speedMps;
    } else {
      rejectedCount++;
    }
    return r;
  }

  TrackerResult _evaluate(Fix fix, DateTime now) {
    if (fix.accuracy <= 0 || fix.accuracy > config.maxAccuracyMeters) {
      return const TrackerResult.rejected(RejectReason.poorAccuracy);
    }
    if (now.difference(fix.timestamp) > config.maxFixAge) {
      return const TrackerResult.rejected(RejectReason.stale);
    }

    final last = _last;
    if (last == null) {
      _last = fix;
      return TrackerResult.accepted(
        speedMps: _trustedPlatformSpeed(fix) ?? 0,
        distanceDelta: 0,
      );
    }

    final dtMs = fix.timestamp.difference(last.timestamp).inMilliseconds;
    if (dtMs <= 0) {
      return const TrackerResult.rejected(RejectReason.outOfOrder);
    }
    final dt = dtMs / 1000.0;
    final dist = haversineMeters(last.lat, last.lng, fix.lat, fix.lng);
    final implied = dist / dt;

    if (implied > config.maxSpeedMps) {
      // Could be a one-off glitch, or the receiver genuinely lost us for a
      // while (tunnel, app restart) and we're now somewhere else. Only
      // re-anchor once several fixes in a row agree with each other.
      _suspects.add(fix);
      // only the last N matter, otherwise one garbage fix at the start of a
      // real relocation blocks the re-anchor forever
      if (_suspects.length > config.suspectsToReanchor) {
        _suspects.removeAt(0);
      }
      if (_suspects.length == config.suspectsToReanchor &&
          _suspectsAreConsistent()) {
        _suspects.clear();
        _last = fix;
        return TrackerResult.accepted(
          speedMps: _trustedPlatformSpeed(fix) ?? 0,
          distanceDelta: 0,
          reanchored: true,
        );
      }
      return const TrackerResult.rejected(RejectReason.jump);
    }
    _suspects.clear();

    final speed = _pickSpeed(fix, implied);

    // Don't let the receiver wandering around while parked inflate the total.
    var delta = dist;
    if (dist < config.minDistanceMeters) {
      delta = 0;
    } else if (fix.speedMps != null &&
        fix.speedMps! < config.stationarySpeedMps &&
        dist < fix.accuracy) {
      delta = 0;
    }

    // Keep the old anchor while stationary so drift doesn't accumulate,
    // but always move it once we actually travelled.
    if (delta > 0) {
      _last = fix;
    } else {
      // still refresh the timestamp, otherwise a long parked period followed
      // by the first real move would look like a giant dt (harmless) - more
      // importantly we want out-of-order detection to keep working.
      _last = Fix(
        lat: last.lat,
        lng: last.lng,
        accuracy: last.accuracy,
        timestamp: fix.timestamp,
        speedMps: fix.speedMps,
        speedAccuracy: fix.speedAccuracy,
        isMocked: fix.isMocked,
      );
    }

    return TrackerResult.accepted(speedMps: speed, distanceDelta: delta);
  }

  /// Platform speed when it looks sane, otherwise the value derived from
  /// distance / time between the last two accepted fixes.
  double _pickSpeed(Fix fix, double implied) {
    final platform = _trustedPlatformSpeed(fix);
    if (platform == null) return implied;
    // A single spiky reading from the chipset shouldn't become the max
    // speed of the trip if the actual movement doesn't back it up.
    if (platform - implied > config.speedDisagreeMps) return implied;
    return platform;
  }

  double? _trustedPlatformSpeed(Fix fix) {
    final s = fix.speedMps;
    if (s == null || s < 0) return null;
    if (s > config.maxSpeedMps) return null;
    final acc = fix.speedAccuracy;
    if (acc != null && acc > 10) return null; // basically a guess
    return s;
  }

  bool _suspectsAreConsistent() {
    for (var i = 1; i < _suspects.length; i++) {
      final a = _suspects[i - 1];
      final b = _suspects[i];
      final dt = b.timestamp.difference(a.timestamp).inMilliseconds / 1000.0;
      if (dt <= 0) return false;
      final d = haversineMeters(a.lat, a.lng, b.lat, b.lng);
      if (d / dt > config.maxSpeedMps) return false;
    }
    return true;
  }
}

double haversineMeters(double lat1, double lon1, double lat2, double lon2) {
  const r = 6371000.0;
  final dLat = _rad(lat2 - lat1);
  final dLon = _rad(lon2 - lon1);
  final a =
      sin(dLat / 2) * sin(dLat / 2) +
      cos(_rad(lat1)) * cos(_rad(lat2)) * sin(dLon / 2) * sin(dLon / 2);
  return 2 * r * atan2(sqrt(a), sqrt(1 - a));
}

double _rad(double deg) => deg * pi / 180.0;
