import 'dart:async';
import 'dart:math';

import 'package:connectivity_plus/connectivity_plus.dart';

import '../data/trip_repository.dart';
import '../models/trip.dart';
import 'api_client.dart';

class SyncStatus {
  const SyncStatus({
    required this.pending,
    this.online = true,
    this.lastError,
    this.lastSuccessAt,
  });
  final int pending;
  final bool online;
  final String? lastError;
  final DateTime? lastSuccessAt;

  Map<String, dynamic> toMap() => {
    'pending': pending,
    'online': online,
    'lastError': lastError,
    'lastSuccessAt': lastSuccessAt?.millisecondsSinceEpoch,
  };
}

/// Pushes whatever is in the local db to the backend, oldest first. The db
/// is the queue; nothing is uploaded straight from the location stream.
class SyncWorker {
  SyncWorker(this._repo, this._api, {this.onStatus, this.onTripEndedByServer});

  final TripRepository _repo;
  final TripApi _api;
  final void Function(SyncStatus status)? onStatus;

  // server says a trip we think is active is over
  final Future<void> Function(String tripId)? onTripEndedByServer;

  StreamSubscription? _connSub;
  Timer? _timer;
  bool _running = false;
  bool _online = true;
  int _failures = 0;
  DateTime? _nextAttempt;
  String? _lastError;
  DateTime? _lastSuccess;

  void start() {
    _connSub = Connectivity().onConnectivityChanged.listen((results) {
      final wasOnline = _online;
      _online = !results.contains(ConnectivityResult.none);
      if (_online && !wasOnline) {
        _failures = 0; // give it a fresh go as soon as we're back
        _nextAttempt = null;
        kick();
      }
      _publish();
    });
    _timer = Timer.periodic(const Duration(seconds: 15), (_) => kick());
    kick();
  }

  Future<void> stop() async {
    await _connSub?.cancel();
    _timer?.cancel();
  }

  Future<void> kick() async {
    if (_running) return;
    if (_nextAttempt != null && DateTime.now().isBefore(_nextAttempt!)) return;
    _running = true;
    try {
      await _drain();
      _failures = 0;
      _nextAttempt = null;
      _lastError = null;
      _lastSuccess = DateTime.now();
    } on TransientApiError catch (e) {
      _failures++;
      final secs = min(pow(2, _failures).toInt(), 60);
      _nextAttempt = DateTime.now().add(Duration(seconds: secs));
      _lastError = e.message;
    } catch (e) {
      _failures++;
      _nextAttempt = DateTime.now().add(const Duration(seconds: 30));
      _lastError = e.toString();
    } finally {
      _running = false;
      await _publish();
    }
  }

  Future<bool> hasPending() async {
    final trips = await _repo.tripsNeedingSync();
    return trips.isNotEmpty;
  }

  Future<void> _drain() async {
    final trips = await _repo.tripsNeedingSync();
    for (final t in trips) {
      await _syncTrip(t);
    }
  }

  Future<void> _syncTrip(Trip trip) async {
    if (!trip.startSynced) {
      try {
        await _api.startTrip(trip);
      } on TripStateConflict catch (e) {
        // 409 here means the server already has it - that's fine, it's
        // most likely our own earlier request whose response got lost.
        if (e.statusCode != 409) rethrow;
      }
      await _repo.markStartSynced(trip.id);
    }

    while (true) {
      final batch = await _repo.unsyncedPoints(trip.id);
      if (batch.isEmpty) break;
      final done = <int>[];
      try {
        for (final p in batch) {
          await _api.uploadLocation(p);
          done.add(p.id);
        }
      } on TripStateConflict {
        await _serverSaysTripIsOver(trip);
        return;
      } finally {
        // keep whatever got through even if we bail mid-batch
        await _repo.markPointsSynced(done);
      }
      await _publish();
    }

    if (trip.status == TripStatus.ended && !trip.endSynced) {
      // re-read: distance/max may have been updated after tripsNeedingSync()
      final fresh = await _repo.getTrip(trip.id) ?? trip;
      try {
        await _api.endTrip(fresh);
      } on TripStateConflict catch (e) {
        if (e.statusCode != 409) rethrow; // already ended -> fine
      }
      await _repo.markEndSynced(trip.id);
    }
  }

  Future<void> _serverSaysTripIsOver(Trip trip) async {
    await _repo.discardUnsynced(trip.id);
    if (trip.status == TripStatus.active) {
      await onTripEndedByServer?.call(trip.id);
    }
    await _repo.markEndSynced(trip.id);
  }

  // startup check: server may have closed the trip while we were away
  Future<void> reconcileActiveTrip(Trip trip) async {
    if (!trip.startSynced) return; // server never heard of it, nothing to check
    try {
      final remote = await _api.getTrip(trip.id);
      final status = remote?['status']?.toString().toLowerCase();
      if (status == 'ended' || status == 'completed') {
        await _serverSaysTripIsOver(trip);
      }
    } on TransientApiError {
      // offline, we'll just carry on with what we have
    }
  }

  Future<void> _publish() async {
    final pending = await _repo.pendingUploadCount();
    onStatus?.call(
      SyncStatus(
        pending: pending,
        online: _online,
        lastError: _lastError,
        lastSuccessAt: _lastSuccess,
      ),
    );
  }
}
