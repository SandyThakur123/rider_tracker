import 'package:dio/dio.dart';

import '../models/track_point.dart';
import '../models/trip.dart';

/// Trip already ended / unknown id. Not retryable.
class TripStateConflict implements Exception {
  TripStateConflict(this.statusCode, this.message);
  final int statusCode;
  final String message;
  @override
  String toString() => 'TripStateConflict($statusCode): $message';
}

/// Network / timeout / 5xx. Retry later.
class TransientApiError implements Exception {
  TransientApiError(this.message);
  final String message;
  @override
  String toString() => 'TransientApiError: $message';
}

abstract class TripApi {
  Future<void> startTrip(Trip trip);
  Future<void> uploadLocation(TrackPoint p);
  Future<void> endTrip(Trip trip);
  Future<Map<String, dynamic>?> getTrip(String id);
}

class ApiClient implements TripApi {
  ApiClient(String baseUrl)
    : _dio = Dio(
        BaseOptions(
          baseUrl: baseUrl,
          connectTimeout: const Duration(seconds: 8),
          receiveTimeout: const Duration(seconds: 8),
          sendTimeout: const Duration(seconds: 8),
          headers: {'Content-Type': 'application/json'},
        ),
      );

  final Dio _dio;

  @override
  Future<void> startTrip(Trip trip) async {
    await _post('/trip/start', {
      'tripId': trip.id,
      'startedAt': trip.startedAt.toIso8601String(),
    }, idempotencyKey: 'start:${trip.id}');
  }

  @override
  Future<void> uploadLocation(TrackPoint p) async {
    await _post('/trip/location', {
      'tripId': p.tripId,
      'latitude': p.fix.lat,
      'longitude': p.fix.lng,
      'speed': p.fix.speedMps ?? 0,
      'accuracy': p.fix.accuracy,
      'timestamp': p.fix.timestamp.toIso8601String(),
    }, idempotencyKey: 'loc:${p.tripId}:${p.id}');
  }

  @override
  Future<void> endTrip(Trip trip) async {
    await _post('/trip/end', {
      'tripId': trip.id,
      'endedAt': trip.endedAt?.toIso8601String(),
      'distanceMeters': trip.distanceMeters,
      'maxSpeed': trip.maxSpeedMps,
    }, idempotencyKey: 'end:${trip.id}');
  }

  // null if the server doesn't know the trip
  @override
  Future<Map<String, dynamic>?> getTrip(String id) async {
    try {
      final res = await _dio.get<Map<String, dynamic>>('/trip/$id');
      return res.data;
    } on DioException catch (e) {
      if (e.response?.statusCode == 404) return null;
      throw _wrap(e);
    }
  }

  Future<void> _post(
    String path,
    Map<String, dynamic> body, {
    required String idempotencyKey,
  }) async {
    try {
      await _dio.post(
        path,
        data: body,
        options: Options(headers: {'Idempotency-Key': idempotencyKey}),
      );
    } on DioException catch (e) {
      throw _wrap(e);
    }
  }

  Exception _wrap(DioException e) {
    final code = e.response?.statusCode;
    if (code == null) return TransientApiError(e.message ?? e.type.name);
    if (code >= 500) return TransientApiError('HTTP $code');
    if (code == 409 || code == 404 || code == 410) {
      return TripStateConflict(code, e.response?.data?.toString() ?? '');
    }
    // 4xx we didn't plan for - retrying won't help but we also don't want
    // to lose data, so surface it as transient and let backoff slow us down.
    return TransientApiError('HTTP $code');
  }
}
