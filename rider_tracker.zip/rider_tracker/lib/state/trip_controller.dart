import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';

import '../config.dart';
import '../data/trip_repository.dart';
import '../models/fix.dart';
import '../models/trip.dart';
import '../tracking/permissions.dart';
import '../tracking/tracking_service.dart';

enum StartOutcome { started, alreadyActive, serviceDisabled, permissionDenied }

class TripController extends ChangeNotifier {
  TripController(this._repo, this._service);

  final TripRepository _repo;
  final TrackingService _service;

  Trip? trip;
  Trip? lastEndedTrip;
  Fix? lastFix;
  double currentSpeedMps = 0;
  bool? lastFixAccepted;
  String? lastRejectReason;
  bool lastReanchored = false;
  LocationPermissionState? permission;
  String? serviceError;
  int pendingUploads = 0;
  bool syncOnline = true;
  String? syncError;
  bool busy = false;

  final _subs = <StreamSubscription>[];
  Timer? _tick;

  bool get hasActiveTrip => trip?.isActive == true;
  bool get syncEnabled => kSyncEnabled;

  Future<void> init() async {
    trip = await _repo.activeTrip();
    permission = await Permissions.current();
    pendingUploads = await _repo.pendingUploadCount();

    _subs.add(_service.updates.listen(_onUpdate));
    _subs.add(
      _service.errors.listen((e) {
        serviceError = e?['message']?.toString();
        notifyListeners();
      }),
    );

    // trip was running when the process died, or uploads are left over
    if (trip != null || (kSyncEnabled && pendingUploads > 0)) {
      await _service.ensureRunning();
    }

    _tick = Timer.periodic(const Duration(seconds: 1), (_) {
      if (hasActiveTrip) notifyListeners();
    });
    notifyListeners();
  }

  void _onUpdate(Map<String, dynamic>? data) {
    if (data == null) return;
    final t = data['trip'];
    final incoming = t == null
        ? null
        : Trip.fromMap(Map<String, dynamic>.from(t));

    if (incoming == null && trip != null) {
      // ended behind our back (server closed it), row already has ended_at
      _loadEnded(trip!.id);
    }
    trip = incoming;

    final f = data['fix'];
    if (f != null) {
      lastFix = Fix.fromMap(Map<String, dynamic>.from(f));
      lastFixAccepted = data['accepted'] as bool?;
      lastRejectReason = data['reason'] as String?;
      lastReanchored = data['reanchored'] == true;
      currentSpeedMps = (data['currentSpeed'] as num?)?.toDouble() ?? 0;
    }
    final s = data['sync'];
    if (s != null) {
      pendingUploads = (s['pending'] as num?)?.toInt() ?? pendingUploads;
      syncOnline = s['online'] != false;
      syncError = s['lastError'] as String?;
    }
    serviceError = null;
    notifyListeners();
  }

  Future<void> _loadEnded(String id) async {
    lastEndedTrip = await _repo.getTrip(id);
    notifyListeners();
  }

  Future<StartOutcome> startTrip() async {
    if (busy) return StartOutcome.alreadyActive;
    busy = true;
    notifyListeners();
    try {
      // guard against double tap / two screens
      final existing = await _repo.activeTrip();
      if (existing != null) {
        trip = existing;
        return StartOutcome.alreadyActive;
      }

      permission = await Permissions.requestForTracking();
      switch (permission!) {
        case LocationPermissionState.serviceDisabled:
          return StartOutcome.serviceDisabled;
        case LocationPermissionState.denied:
        case LocationPermissionState.deniedForever:
          return StartOutcome.permissionDenied;
        case LocationPermissionState.whileInUse:
        case LocationPermissionState.always:
          break;
      }

      final t = Trip(
        id: 'TRIP-${const Uuid().v4()}',
        status: TripStatus.active,
        startedAt: DateTime.now().toUtc(),
      );
      await _repo.insertTrip(t);
      trip = t;
      lastFix = null;
      lastFixAccepted = null;
      lastRejectReason = null;
      currentSpeedMps = 0;
      serviceError = null;
      lastEndedTrip = null;

      await _service.ensureRunning();
      return StartOutcome.started;
    } finally {
      busy = false;
      notifyListeners();
    }
  }

  Future<void> endTrip() async {
    final t = trip;
    if (t == null || busy) return;
    busy = true;
    notifyListeners();
    try {
      final ended = await _repo.endTrip(t.id);
      if (ended) {
        lastEndedTrip = await _repo.getTrip(t.id);
      }
      trip = null;
      currentSpeedMps = 0;
      // service will notice the trip is gone, stop the stream and flush uploads
      _service.refresh();
    } finally {
      busy = false;
      notifyListeners();
    }
  }

  Future<void> refreshPermission() async {
    permission = await Permissions.current();
    notifyListeners();
  }

  @override
  void dispose() {
    for (final s in _subs) {
      s.cancel();
    }
    _tick?.cancel();
    super.dispose();
  }
}
