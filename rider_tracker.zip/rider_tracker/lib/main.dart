import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'data/app_database.dart';
import 'data/trip_repository.dart';
import 'state/trip_controller.dart';
import 'tracking/tracking_service.dart';
import 'ui/home_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await TrackingService.configure();

  final db = await AppDatabase.open();
  final repo = TripRepository(db);
  final controller = TripController(repo, TrackingService());
  await controller.init();

  runApp(RiderApp(repo: repo, controller: controller));
}

class RiderApp extends StatelessWidget {
  const RiderApp({super.key, required this.repo, required this.controller});

  final TripRepository repo;
  final TripController controller;

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        Provider<TripRepository>.value(value: repo),
        ChangeNotifierProvider<TripController>.value(value: controller),
      ],
      child: MaterialApp(
        title: 'Rider Tracker',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          colorSchemeSeed: const Color(0xFF1E6FD9),
          useMaterial3: true,
        ),
        darkTheme: ThemeData(
          colorSchemeSeed: const Color(0xFF1E6FD9),
          brightness: Brightness.dark,
          useMaterial3: true,
        ),
        home: const HomeScreen(),
      ),
    );
  }
}
