import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:provider/provider.dart';

import '../models/trip.dart';
import '../state/trip_controller.dart';
import '../tracking/permissions.dart';
import 'format.dart';
import 'history_screen.dart';
import 'widgets/stat_tile.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final c = context.watch<TripController>();
    final trip = c.trip;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Rider Tracker'),
        actions: [
          IconButton(
            icon: const Icon(Icons.history),
            tooltip: 'Past trips',
            onPressed: () => Navigator.of(
              context,
            ).push(MaterialPageRoute(builder: (_) => const HistoryScreen())),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          children: [
            _StatusCard(trip: trip, lastEnded: c.lastEndedTrip),
            const SizedBox(height: 12),
            ..._warnings(context, c),
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              childAspectRatio: 1.7,
              children: [
                StatTile(
                  label: 'Distance',
                  icon: Icons.route,
                  value: fmtKm(
                    trip?.distanceMeters ??
                        c.lastEndedTrip?.distanceMeters ??
                        0,
                  ),
                  highlight: true,
                ),
                StatTile(
                  label: 'Duration',
                  icon: Icons.timer_outlined,
                  value: fmtDuration(
                    trip?.duration ??
                        c.lastEndedTrip?.duration ??
                        Duration.zero,
                  ),
                ),
                StatTile(
                  label: 'Speed',
                  icon: Icons.speed,
                  value: fmtKmh(trip == null ? 0 : c.currentSpeedMps),
                ),
                StatTile(
                  label: 'Max speed',
                  icon: Icons.trending_up,
                  value: fmtKmh(
                    trip?.maxSpeedMps ?? c.lastEndedTrip?.maxSpeedMps ?? 0,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            _GpsCard(controller: c),
            if (c.syncEnabled) ...[
              const SizedBox(height: 12),
              _SyncCard(controller: c),
            ],
            const SizedBox(height: 24),
            _ActionButton(controller: c),
          ],
        ),
      ),
    );
  }

  List<Widget> _warnings(BuildContext context, TripController c) {
    final out = <Widget>[];
    final perm = c.permission;

    if (c.hasActiveTrip && perm == LocationPermissionState.whileInUse) {
      out.add(
        _Banner(
          icon: Icons.warning_amber_rounded,
          text:
              'Location is set to "While using". Tracking will not resume on its '
              'own after a reboot or if the system stops the app. Set it to '
              '"Always" for that.',
          action: 'Settings',
          onAction: () => Geolocator.openAppSettings(),
        ),
      );
    }
    if (perm == LocationPermissionState.deniedForever) {
      out.add(
        _Banner(
          icon: Icons.location_off,
          text: 'Location permission is blocked. Enable it in app settings.',
          action: 'Settings',
          onAction: () => Geolocator.openAppSettings(),
        ),
      );
    }
    if (perm == LocationPermissionState.serviceDisabled) {
      out.add(
        _Banner(
          icon: Icons.location_disabled,
          text: 'Location services are turned off on this device.',
          action: 'Turn on',
          onAction: () => Geolocator.openLocationSettings(),
        ),
      );
    }
    if (c.serviceError != null) {
      out.add(
        _Banner(
          icon: Icons.error_outline,
          text: 'Location error: ${c.serviceError}',
        ),
      );
    }
    if (out.isNotEmpty) out.add(const SizedBox(height: 12));
    return out;
  }
}

class _StatusCard extends StatelessWidget {
  const _StatusCard({required this.trip, required this.lastEnded});

  final Trip? trip;
  final Trip? lastEnded;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final active = trip != null;

    final color = active ? Colors.green : scheme.outline;
    final title = active
        ? 'Trip in progress'
        : lastEnded != null
        ? 'Last trip ended'
        : 'No active trip';
    final subtitle = active
        ? 'Started ${fmtTime(trip!.startedAt)} · ${trip!.id.substring(0, 13)}'
        : lastEnded != null
        ? '${fmtDateTime(lastEnded!.startedAt)} · ${fmtDuration(lastEnded!.duration)}'
        : 'Tap Start Trip to begin tracking';

    return Card(
      elevation: 0,
      color: scheme.surfaceContainerLow,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Container(
              width: 12,
              height: 12,
              decoration: BoxDecoration(color: color, shape: BoxShape.circle),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: theme.textTheme.titleMedium),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: scheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _GpsCard extends StatelessWidget {
  const _GpsCard({required this.controller});
  final TripController controller;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final c = controller;
    final fix = c.lastFix;
    final trip = c.trip;

    String fixLine;
    Color? fixColor;
    if (fix == null) {
      fixLine = c.hasActiveTrip ? 'Waiting for first fix…' : '—';
    } else if (c.lastFixAccepted == false) {
      fixLine = 'Rejected: ${reasonLabel(c.lastRejectReason)}';
      fixColor = scheme.error;
    } else if (c.lastReanchored) {
      fixLine = 'Re-anchored after GPS jump';
      fixColor = Colors.orange.shade800;
    } else {
      fixLine = 'OK';
      fixColor = Colors.green.shade700;
    }

    return Card(
      elevation: 0,
      color: scheme.surfaceContainerLow,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.gps_fixed, size: 18, color: scheme.onSurfaceVariant),
                const SizedBox(width: 8),
                Text('Location', style: theme.textTheme.titleSmall),
                const Spacer(),
                Text(
                  fixLine,
                  style: theme.textTheme.bodySmall?.copyWith(color: fixColor),
                ),
              ],
            ),
            const SizedBox(height: 10),
            if (fix != null) ...[
              _kv(
                'Lat / Lng',
                '${fix.lat.toStringAsFixed(6)}, ${fix.lng.toStringAsFixed(6)}',
              ),
              _kv('Accuracy', '±${fix.accuracy.toStringAsFixed(0)} m'),
              _kv(
                'Platform speed',
                fix.speedMps == null ? 'n/a' : fmtKmh(fix.speedMps!),
              ),
              _kv(
                'Updated',
                '${fmtTime(fix.timestamp)} (${fmtAge(fix.timestamp)})',
              ),
              if (fix.isMocked) _kv('Source', 'mock location'),
            ],
            if (trip != null)
              _kv(
                'Fixes',
                '${trip.acceptedCount} accepted · ${trip.rejectedCount} rejected',
              ),
          ],
        ),
      ),
    );
  }

  Widget _kv(String k, String v) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 2),
    child: Row(
      children: [
        SizedBox(
          width: 110,
          child: Text(k, style: const TextStyle(fontSize: 13)),
        ),
        Expanded(
          child: Text(
            v,
            style: const TextStyle(
              fontSize: 13,
              fontFeatures: [FontFeature.tabularFigures()],
            ),
          ),
        ),
      ],
    ),
  );
}

class _SyncCard extends StatelessWidget {
  const _SyncCard({required this.controller});
  final TripController controller;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final c = controller;
    final String status;
    final IconData icon;
    if (!c.syncOnline) {
      status = 'Offline · ${c.pendingUploads} queued';
      icon = Icons.cloud_off;
    } else if (c.syncError != null) {
      status = 'Retrying (${c.syncError}) · ${c.pendingUploads} queued';
      icon = Icons.cloud_sync;
    } else if (c.pendingUploads > 0) {
      status = 'Uploading · ${c.pendingUploads} left';
      icon = Icons.cloud_upload_outlined;
    } else {
      status = 'Up to date';
      icon = Icons.cloud_done_outlined;
    }
    return Card(
      elevation: 0,
      color: scheme.surfaceContainerLow,
      child: ListTile(
        dense: true,
        leading: Icon(icon, color: scheme.onSurfaceVariant),
        title: Text('Sync', style: theme.textTheme.titleSmall),
        subtitle: Text(status),
      ),
    );
  }
}

class _ActionButton extends StatelessWidget {
  const _ActionButton({required this.controller});
  final TripController controller;

  @override
  Widget build(BuildContext context) {
    final c = controller;
    final active = c.hasActiveTrip;
    return SizedBox(
      height: 56,
      child: FilledButton.icon(
        style: FilledButton.styleFrom(
          backgroundColor: active ? Colors.red.shade700 : null,
        ),
        icon: Icon(active ? Icons.stop_circle_outlined : Icons.play_arrow),
        label: Text(
          active ? 'End Trip' : 'Start Trip',
          style: const TextStyle(fontSize: 18),
        ),
        onPressed: c.busy
            ? null
            : () => active ? _end(context) : _start(context),
      ),
    );
  }

  Future<void> _start(BuildContext context) async {
    final messenger = ScaffoldMessenger.of(context);
    final outcome = await controller.startTrip();
    switch (outcome) {
      case StartOutcome.started:
      case StartOutcome.alreadyActive:
        break;
      case StartOutcome.serviceDisabled:
        messenger.showSnackBar(
          const SnackBar(
            content: Text('Turn on location services to start a trip'),
          ),
        );
        break;
      case StartOutcome.permissionDenied:
        messenger.showSnackBar(
          const SnackBar(
            content: Text('Location permission is needed to track a trip'),
          ),
        );
        break;
    }
  }

  Future<void> _end(BuildContext context) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('End trip?'),
        content: const Text('Tracking will stop and the trip will be saved.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('End trip'),
          ),
        ],
      ),
    );
    if (ok == true) await controller.endTrip();
  }
}

class _Banner extends StatelessWidget {
  const _Banner({
    required this.icon,
    required this.text,
    this.action,
    this.onAction,
  });

  final IconData icon;
  final String text;
  final String? action;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.fromLTRB(12, 10, 8, 10),
      decoration: BoxDecoration(
        color: scheme.errorContainer,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          Icon(icon, color: scheme.onErrorContainer, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              text,
              style: TextStyle(color: scheme.onErrorContainer, fontSize: 13),
            ),
          ),
          if (action != null)
            TextButton(onPressed: onAction, child: Text(action!)),
        ],
      ),
    );
  }
}
