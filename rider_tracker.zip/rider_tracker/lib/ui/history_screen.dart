import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../data/trip_repository.dart';
import '../models/track_point.dart';
import '../models/trip.dart';
import 'format.dart';

class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final repo = context.read<TripRepository>();
    return Scaffold(
      appBar: AppBar(title: const Text('Past trips')),
      body: FutureBuilder<List<Trip>>(
        future: repo.allTrips(),
        builder: (context, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final trips = snap.data!;
          if (trips.isEmpty) {
            return const Center(child: Text('No trips yet'));
          }
          return ListView.separated(
            itemCount: trips.length,
            separatorBuilder: (_, _) => const Divider(height: 1),
            itemBuilder: (context, i) {
              final t = trips[i];
              return ListTile(
                leading: Icon(
                  t.isActive ? Icons.play_circle : Icons.check_circle_outline,
                  color: t.isActive ? Colors.green : null,
                ),
                title: Text(
                  '${fmtKm(t.distanceMeters)} · ${fmtDuration(t.duration)}',
                ),
                subtitle: Text(
                  '${fmtDateTime(t.startedAt)} · max ${fmtKmh(t.maxSpeedMps)}',
                ),
                trailing: _syncIcon(t),
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => TripDetailScreen(trip: t)),
                ),
              );
            },
          );
        },
      ),
    );
  }

  Widget _syncIcon(Trip t) {
    if (t.startSynced && (t.isActive || t.endSynced)) {
      return const Icon(Icons.cloud_done_outlined, size: 18);
    }
    return const Icon(Icons.cloud_upload_outlined, size: 18);
  }
}

class TripDetailScreen extends StatelessWidget {
  const TripDetailScreen({super.key, required this.trip});
  final Trip trip;

  @override
  Widget build(BuildContext context) {
    final repo = context.read<TripRepository>();
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(trip.id.substring(0, 13))),
      body: FutureBuilder<List<TrackPoint>>(
        future: repo.pointsForTrip(trip.id),
        builder: (context, snap) {
          final points = snap.data ?? const <TrackPoint>[];
          return ListView(
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      fmtKm(trip.distanceMeters),
                      style: theme.textTheme.displaySmall,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${fmtDateTime(trip.startedAt)} → '
                      '${trip.endedAt == null ? 'now' : fmtTime(trip.endedAt!)}',
                    ),
                    Text(
                      'Duration ${fmtDuration(trip.duration)} · '
                      'max ${fmtKmh(trip.maxSpeedMps)}',
                    ),
                    Text(
                      '${trip.acceptedCount} fixes accepted, '
                      '${trip.rejectedCount} rejected',
                    ),
                    if (trip.endedAt != null && trip.duration.inSeconds > 0)
                      Text(
                        'Average ${fmtKmh(trip.distanceMeters / trip.duration.inSeconds)}',
                      ),
                  ],
                ),
              ),
              const Divider(height: 1),
              if (snap.connectionState != ConnectionState.done)
                const Padding(
                  padding: EdgeInsets.all(24),
                  child: Center(child: CircularProgressIndicator()),
                ),
              // raw log, newest first - handy when checking the filter on a
              // real ride
              for (final p in points.reversed)
                ListTile(
                  dense: true,
                  leading: Icon(
                    p.accepted ? Icons.check : Icons.close,
                    size: 18,
                    color: p.accepted ? Colors.green : Colors.red,
                  ),
                  title: Text(
                    '${p.fix.lat.toStringAsFixed(5)}, ${p.fix.lng.toStringAsFixed(5)}',
                    style: const TextStyle(
                      fontFeatures: [FontFeature.tabularFigures()],
                    ),
                  ),
                  subtitle: Text(
                    '${fmtTime(p.fix.timestamp)} · ±${p.fix.accuracy.toStringAsFixed(0)}m'
                    '${p.fix.speedMps != null ? ' · ${fmtKmh(p.fix.speedMps!)}' : ''}'
                    '${p.accepted ? '' : ' · ${reasonLabel(p.rejectReason)}'}',
                  ),
                  trailing: p.accepted && !p.synced
                      ? const Icon(Icons.cloud_upload_outlined, size: 16)
                      : null,
                ),
            ],
          );
        },
      ),
    );
  }
}
