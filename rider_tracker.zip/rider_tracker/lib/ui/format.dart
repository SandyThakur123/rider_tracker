import 'package:intl/intl.dart';

import '../tracking/trip_tracker.dart';

String fmtKm(double meters) {
  if (meters < 1000) return '${meters.toStringAsFixed(0)} m';
  return '${(meters / 1000).toStringAsFixed(2)} km';
}

String fmtKmh(double mps) => '${(mps * 3.6).toStringAsFixed(1)} km/h';

String fmtDuration(Duration d) {
  final h = d.inHours;
  final m = d.inMinutes.remainder(60);
  final s = d.inSeconds.remainder(60);
  String two(int n) => n.toString().padLeft(2, '0');
  return h > 0 ? '${two(h)}:${two(m)}:${two(s)}' : '${two(m)}:${two(s)}';
}

String fmtTime(DateTime t) => DateFormat('HH:mm:ss').format(t.toLocal());
String fmtDateTime(DateTime t) =>
    DateFormat('d MMM, HH:mm').format(t.toLocal());

String fmtAge(DateTime t) {
  final s = DateTime.now().toUtc().difference(t).inSeconds;
  if (s < 2) return 'just now';
  if (s < 60) return '${s}s ago';
  return '${s ~/ 60}m ago';
}

String reasonLabel(String? reason) {
  switch (reason) {
    case RejectReason.poorAccuracy:
      return 'poor accuracy';
    case RejectReason.stale:
      return 'stale fix';
    case RejectReason.outOfOrder:
      return 'out of order';
    case RejectReason.jump:
      return 'GPS jump';
    default:
      return reason ?? '';
  }
}
