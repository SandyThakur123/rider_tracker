# Rider Tracker

Flutter app that tracks a rider's trip from Start to End: live position,
distance, current and max speed. Tracking keeps running in the background and
survives the process being killed. Works fully offline; backend sync is
optional.

## Setup

Requires Flutter 3.44 / Dart 3.12 or newer.

```
flutter pub get
flutter run
```

Location needs a real device, or an emulator with a mock route (see
"Testing" below).

With a backend:

```
dart run tool/mock_server.dart                                  # terminal 1
flutter run --dart-define=API_BASE_URL=http://10.0.2.2:8080     # android emulator
flutter run --dart-define=API_BASE_URL=http://192.168.x.x:8080  # real device, use your machine's LAN ip
```

If `API_BASE_URL` is not set the app is local-only and the sync card is
hidden.

Tests:

```
flutter test
```

## How it's put together

```
lib/
  config.dart               thresholds for the GPS filter, API url
  models/                   Trip, Fix, TrackPoint
  data/                     sqlite schema + repository
  tracking/
    trip_tracker.dart       pure-dart filter: takes fixes, keeps distance / max speed
    tracking_service.dart   background isolate: location stream -> tracker -> db
    permissions.dart
  sync/
    api_client.dart         dio wrapper, maps http errors to transient / conflict
    sync_worker.dart        drains the db to the backend with backoff
  state/trip_controller.dart  what the UI binds to
  ui/
tool/mock_server.dart       throwaway backend for local testing
```

The main decision is that sqlite is the source of truth and the background
service is the only thing that reads GPS. The UI never touches the location
plugin. Start Trip inserts a row with `status = active` and pokes the service;
End Trip flips the row and pokes it again. The service reads the db on every
poke (and on its own startup) and decides whether it should be streaming
location. This is the same code path for: normal start, resume after the OS
killed the process, resume after reboot. There is no separate "recovery" logic.

Every fix goes into the `points` table, accepted or not, with a reject reason.
That turned out to be the most useful thing for tuning the filter on a real
ride; the trip detail screen shows the raw log.

Trip stats (distance, max, counts) are written to the `trips` row after every
accepted fix, so at most one fix is lost if the process dies.

### GPS filtering (`trip_tracker.dart`)

In order, for each fix:

1. Accuracy worse than 50 m: reject. Anything better than that is fine for
   a road vehicle, the number is in `config.dart`.
2. Stale: fix timestamp older than 30 s relative to now, reject. Android
   likes to hand you the last cached position as the first event of a new
   stream, sometimes from hours ago.
3. Out of order timestamp: reject.
4. Jump: implied speed from the last accepted fix (haversine / dt) above
   45 m/s (~160 km/h) is rejected, but remembered as a "suspect". If three
   suspects in a row are consistent with each other (normal speed between
   them) the receiver has genuinely moved, so we re-anchor there and continue
   without counting the gap. Single glitches never get through; a tunnel or
   an app restart with a long gap does.
5. Stationary drift: platform speed below 0.5 m/s and movement smaller
   than the accuracy radius. The fix is accepted but adds 0 m and the old
   anchor is kept. Without this, waiting at a traffic light for 2 minutes
   adds 40 m of noise.
6. Speed: use the platform's value when it's plausible (present, below
   the ceiling, speedAccuracy under 10 m/s) and not wildly above what the
   distance/time says. Otherwise use the derived value. Max speed is only
   ever updated from this filtered number, so a single spiky chipset reading
   can't become the trip's max.

Distance is the sum of haversine between consecutive accepted fixes. With the
platform `distanceFilter` at 5 m and the minimum-move check at 2 m this
under-counts tight curves slightly; that's the safer direction to err.

### Sync (`sync_worker.dart`)

The db is the upload queue. Nothing is sent from the location callback. The
worker wakes on: a new accepted fix, connectivity coming back, a 15 s timer.
For each trip with unsynced work it does start, then points (oldest first,
batches of 50), then end. Failures back off exponentially up to 60 s.

Every POST carries an `Idempotency-Key` (`start:<trip>`, `loc:<trip>:<point
id>`, `end:<trip>`). A 409 on start or end is treated as "the server already
has it" and marked done, which covers the lost-response case. A 409/404/410 on a
location upload means the server thinks the trip is over: remaining points for
that trip are discarded, the trip is ended locally, and the UI updates. On
startup with an active trip we also `GET /trip/{id}` and close the trip if the
server says so.

## Foreground / background / terminated

| | Android | iOS |
|---|---|---|
| App open | location stream in the service isolate | same, main isolate |
| Background / screen locked | foreground service with a persistent notification (`foregroundServiceType="location"`). Runs indefinitely, "While using" permission is enough. | `UIBackgroundModes: location` + `allowBackgroundLocationUpdates`. Runs indefinitely as long as the trip was started with the app in front; "While Using" is enough for that, "Always" is needed to (re)start tracking from the background. |
| Swiped from recents | service is `stopWithTask="false"`, keeps running | iOS kills the process. Tracking stops. Trip stays `active` in the db and resumes the moment the app is opened again; the gap is not counted as distance. |
| Killed by OS (low memory) | Android restarts sticky services; the service re-reads the db and resumes | same as above, nothing runs until the user reopens the app |
| Reboot | boot receiver starts the service, which finds the active trip in the db and resumes | not possible. Resumes on next launch. |
| Force stop from settings | nothing runs until next launch (Android policy) | n/a |

What "resume" means concretely: the tracker is rebuilt from the trip row's
distance/max/counts and the last accepted point in the db. The first new fix
is then checked against that point like any other, so a long gap with a big
displacement counts as one straight-line segment (if the implied speed is
plausible) or triggers the re-anchor logic (if it isn't).

iOS specifics worth knowing:

- Apple has no equivalent of a foreground service. The only way to keep GPS
  running with the app terminated is `startMonitoringSignificantLocationChanges`,
  which relaunches the app on ~500 m cell changes. That's far too coarse for
  distance/speed, so it isn't used; the honest answer is that terminated-app
  tracking on iOS is a gap.
- Background fetch (`onIosBackground`) is registered but only used to flush
  pending uploads. iOS decides when it runs, typically a few times a day.
- The blue "app is using your location" indicator is shown deliberately
  (`showBackgroundLocationIndicator`).

Android specifics:

- Android 14+ requires `FOREGROUND_SERVICE_LOCATION` and the service type in
  the manifest, both are there.
- Starting a location foreground service from the boot receiver is only
  allowed if the user granted "Allow all the time". With "While using" the
  boot resume silently fails and the trip resumes on next launch instead.
- Some OEMs (Xiaomi, Oppo, Samsung with aggressive battery settings) kill
  foreground services anyway. The app can't do anything about that beyond
  what it already does; the user has to whitelist it.

## Testing the edge cases

Mock route on emulators: Android Studio, Extended controls > Location >
Routes. Xcode, Debug > Simulate Location > City Run / Freeway Drive.
`adb emu geo fix <lng> <lat>` works for single points.

GPS jump. With a trip running and a route playing, push a single point a
few km away (`adb emu geo fix 77.30 28.70`, or in Xcode pick a custom
location once), then let the route continue. Location card shows
"Rejected: GPS jump", distance and max speed don't move. In trip detail the
point is there with a red cross.

Receiver actually relocated. Push three or four points in a row from the
new place, ~10 m apart. The third shows "Re-anchored after GPS jump", distance
unchanged, and subsequent points count normally from there.

Noisy speed. Hard to fake through the emulator since it derives speed from
the route; the unit test `platform speed spike is replaced by derived speed`
covers it. On a real device you'll see it at trip start when the chipset
reports 20+ km/h while you're standing still, max speed stays at 0.

Stationary drift. Start a trip and leave the phone on a table for 5
minutes. Distance should stay at 0 m even though the Location card keeps
updating. (Indoors, accuracy may be >50 m and you'll see "Rejected: poor
accuracy" instead, which is also correct.)

Background / locked. Start a trip, lock the phone, walk or drive. Android:
notification shows live distance. Unlock, stats have kept going. iOS: the
blue location pill stays in the status bar; unlock and the stats have kept
going.

App killed. Start a trip, swipe it away from recents.
Android: notification stays, tracking continues; reopen and the same trip is
shown. `adb shell am kill <package>` (not `force-stop`) also works, the
service comes back on its own.
iOS: reopen the app, trip is still active, stats are intact, tracking resumes.

Reboot. Android only. Start a trip, reboot, don't open the app. Within a
minute the tracking notification appears. Needs "Allow all the time".

Offline. Airplane mode mid-trip. Points keep being written (fix counter on
the Location card keeps going); the Sync card shows "Offline · N queued".
Airplane mode off, it goes "Uploading" then "Up to date" within a few seconds. Check
`GET /trip/{id}` on the mock server, `locationCount` matches the accepted
count on the device.

Server error / timeout. With the mock server:
`curl -X PUT localhost:8080/debug/fail/5` makes the next 5 requests return 503. Sync
card shows "Retrying (HTTP 503)" with growing intervals, then recovers.
`curl -X PUT localhost:8080/debug/delay/10000` makes every request take 10 s,
longer than the 8 s client timeout. Same behaviour, error text is the timeout.
Set it back with `/debug/delay/0`.

Duplicate submissions. Tap Start or End several times quickly; the
button disables while busy and the db has a single-active-trip guard, so
nothing happens. On the wire: kill the app right after a start, reopen; the
start is retried with the same idempotency key and the mock server logs
`replay of start:TRIP-..., ok`. Set `/debug/fail/1` right before End to see
the same on `/trip/end`.

Server and device disagree. Trip running and synced.
`curl -X PUT localhost:8080/debug/end/<tripId>`. On the next upload the
device gets a 409, ends the trip locally, and the home screen flips to
"Last trip ended". Or: kill the app first, end the trip on the server, reopen,
and the startup reconciliation closes it before tracking restarts.

## Things I'd do next

- Map view of the route; the points are all in the db already.
- Batch endpoint for location uploads. 1 request per point is fine for the
  assignment but wasteful over cellular.
- A Kalman filter instead of the threshold rules would give smoother speed;
  the threshold approach was chosen because every decision it makes is
  explainable from the reject reason in the log.
- iOS: significant-location-change as a last resort to at least re-launch the
  app after termination and prompt the rider.
